package id.ac.umn.myumn;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    FirebaseAuth mAuth;
    EditText etEmail, etPass;
    Button btnLogin, btnShowHide;
    boolean status;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        status = true;

        etEmail = findViewById(R.id.emailHint);
        etPass = findViewById(R.id.passHint);
        btnLogin = findViewById(R.id.btnSign);
        btnShowHide = findViewById(R.id.btnShow);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String uname = etEmail.getText().toString();
                String password = etPass.getText().toString();

                if (uname.equals("")){
                    Toast.makeText(Login.this,"Silahkan Input Email", Toast.LENGTH_SHORT).show();
                }
                else if(password.equals("")){
                    Toast.makeText(Login.this,"Silahkan Input Password", Toast.LENGTH_SHORT).show();
                }

                mAuth.signInWithEmailAndPassword(uname, password)
                        .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(Login.this, "Login Berhasil.", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(getApplicationContext(), Dashboard.class));
                                } else {
                                    Toast.makeText(Login.this, "Login Gagal.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });

        btnShowHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (status) {
                    etPass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    status = false;
                    etPass.setSelection(etPass.length());
                } else {
                    etPass.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_CLASS_TEXT);
                    status = true;
                    etPass.setSelection(etPass.length());
                }
            }
        });
    }
}
